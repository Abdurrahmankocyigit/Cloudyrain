//
//  CloudyrainApp.swift
//  Cloudyrain
//
//  Created by Abdu Kocyigit on 16.02.22.
//

import SwiftUI

@main
struct CloudyrainApp: App {
    var body: some Scene {
        WindowGroup {
            MainMessagesView()
        }
    }
}


