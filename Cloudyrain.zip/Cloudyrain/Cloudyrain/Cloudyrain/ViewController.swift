//
//  ViewController.swift
//  Cloudyrain
//
//  Created by Abdu Kocyigit on 22.02.22.
//

import Foundation
import UIKit
import UserNotifications
import Firebase

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let center = UNUserNotificationCenter.current()
        
        center.requestAuthorization(options: [.alert, .sound])
        { (granted, error) in
            
        }
        
        let content = UNMutableNotificationContent()
        content.title = "New Message in Cloudyrain?"
        content.body = "Check your Message!"
        
        let date = Date().addingTimeInterval(5)
        
        let dateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        
        let uuidString = UUID().uuidString
        
        let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
        
        center.add(request) { (error) in
            
        }
    }
}
